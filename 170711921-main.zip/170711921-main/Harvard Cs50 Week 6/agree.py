#Cs50 Week 6 Program 8
#Exploring the utility of lists in python

choice = input("Do you agree? ")

if choice == "y" or choice =="Y":
    print("Agreed")
elif choice == "n" or choice == "N":
    print("Not Agreed")




