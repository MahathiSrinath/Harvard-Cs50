#Cs50 Week 6 Program 13
#mario improv Program 1
#Printing ? blocks
#Instead of loop such a syntactic sugar can be used
print("?"*4)
