#Cs50 Week 6 Program 9
#Uppercase improv Program 1

before = input("Before: ")
print("After: ", end = "")
#strings come with inbuilt methods
print(before.upper())
