#Cs50 Week 6 Program 9

before = input("Before: ")
print("After: ", end = "")
#end is used as arguement to avoid next line after each character
#By default end is set to \n
for c in before:
    print(c.upper(), end = "")
print() #used to take cursor to next line

