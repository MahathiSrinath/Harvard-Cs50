#Cs50 Week 6 Program 7
#Using Conditionals
from cs50 import get_int

num1 = get_int("Enter the first value: ")
num2 = get_int("Enter the second value: ")

if(num1 > num2):
    print(f"{num1} is greater than {num2}")
elif(num1 == num2):
    print(f"{num1} is equal to {num2}")
else:
    print(f"{num1} is lesser than {num2}")
