#Cs50 Week 6 Program 4
from PIL import Image,ImageFilter

before = Image.open("courtyard.bmp")
after = before.filter(ImageFilter.FIND_EDGES)
after.save("out.bmp")
