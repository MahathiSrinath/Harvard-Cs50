#Cs50 Week 6 Program 8
#Agree improv Program 1
#Exploring the utility of lists in python

choice = input("Do you agree? ")

#forcing input to lowercase
#choice = input("Do you agree? ").lowe() is a more effecient way
choice = choice.lower()

#list of possiblities checking
if choice in ["y","yes"]:
    print("Agreed")
elif choice in ["n","no"]:
    print("Not Agreed")

