#Cs50 Week 6 Program 3
from PIL import Image,ImageFilter

before = Image.open("courtyard.bmp")
after = before.filter(ImageFilter.BoxBlur(3))
after.save("out.bmp")
