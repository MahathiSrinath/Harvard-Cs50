#Cs50 Week 6 Program 1
print('Jai Guru-Ganapathy-Devi')
