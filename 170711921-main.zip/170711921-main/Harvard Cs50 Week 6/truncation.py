#Cs50 Week 6 Program 11
#Exploring differences in truncation in C and Python

num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))
#Values get type casted by default in python
quotient = num1/num2

print(f"Quotient: {quotient}")

