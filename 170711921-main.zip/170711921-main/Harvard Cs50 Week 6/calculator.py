#Cs50 Week 6 Program 6
#Simple Calculator Program

#int(input()) is the equivalent of get_int
num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

sum = num1 + num2

print(f"Sum = {sum}")
