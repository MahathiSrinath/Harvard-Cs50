#Cs50 Week 6 Program 10
#Using Loops and user defined functions

def main():
        meow(3)

def meow(n):
    for i in range(n):
        print("meow")

main()





