#Cs50 Week 6 Program 16
#Command line arguements
from sys import argv

if len(argv) == 2:
    print(f"hello,{argv[1]}")
else:
    print("hello,world!")

