#Cs50 Week 6 Program 15

names = ["Carter","David","John"]

name = input("Name: ")

for n in names:
    if name == n:
        print("Found")
        break
#OR if name in names:
#       print("Found")
#Python will implement linear search automatically
else:
    print("Not found")
