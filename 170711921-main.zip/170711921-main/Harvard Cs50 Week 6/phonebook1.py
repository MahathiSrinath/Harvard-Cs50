#Cs50 Week 6 Program 15
#Implementing Dictionaries

people = [#comma is added for stylistic purpose not syntax
    {"name": "minz",
     "number":"+91-111"},
    {"name": "mahathi",
     "number":"+91-333"},
    {"name": "mahima",
     "number":"+91-1111"},
     ]

name = input("Name: ")

for person in people:
    if person["name"] == name:
        number = person["number"]
        print("Found")
        print(number)
else:
    print("Not found")
