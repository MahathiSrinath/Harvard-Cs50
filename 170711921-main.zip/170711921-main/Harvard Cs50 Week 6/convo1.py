#Cs50 Week 6 Program 5
#Convo improv Program 1

answer = input("What is your name? ")
print(f"Hello, {answer}")
