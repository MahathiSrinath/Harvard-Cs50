#Cs50 Week 6 Program 13
#Implementing loops to print patterns
from cs50 import get_int

while True:
    n = get_int("Enter the height: ")
    if(n > 0):
        break
    

for i in range(n):
    for j in range(i):
        print("#")
    print()
