#Cs50 Week 6 Program 14
#Scores improv Program 1
from cs50 import get_int

scores = []

for i in range(3):
    score = get_int("Score: ")
    scores.append(score)
    #OR scores = scores +[score] appends values
average = sum(scores)/len(scores)
print(average)



