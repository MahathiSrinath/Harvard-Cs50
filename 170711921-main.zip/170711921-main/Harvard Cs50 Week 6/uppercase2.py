#Cs50 Week 6 Program 9
#Uppercase improv Program 2

before = input("Before: ")
print(f"After: {before.upper()}")
#strings come with inbuilt methods

