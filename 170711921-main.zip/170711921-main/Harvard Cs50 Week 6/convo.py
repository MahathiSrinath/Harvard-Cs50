#Cs50 Week 6 Program 5
from cs50 import get_string
#Might as well very well use the input() instead of get_string()
answer = get_string("What is your name? ")
#Different styles of achieving the same result
print("Hello, " +answer)
print("Hello,",answer)
print(f"Hello, {answer}")
