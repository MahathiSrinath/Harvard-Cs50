#Cs50 Week 6 Program 12
#Exploring Exceptions
#In C we can return numerical values for an error
#But Python does not offer such a thing but we have exceptions

def get_int(prompt):
    while True:
        try:
            return int(input(prompt))
        except ValueError:
#could also simply use pass and keep prompting the user for an int
            print("Not an integer")

def main():

    num1 = get_int("Enter the first number: ")
    num2 = get_int("Enter the second number: ")

    sum = num1 + num2

    print(f"Sum = {sum}")

main()
