#Cs50 Week 6 Program 14
#Exploring Lists

scores = [72,73,33]
average = sum(scores)/len(scores)
print(average)

