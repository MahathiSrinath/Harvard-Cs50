#Cs50 Week 6 Program 13
#mario improv Program 2
#Printing a grid
from cs50 import get_int

while True:
    n = get_int("Enter the height: ")
    if(n > 0):
        break


for i in range(n):
    for j in range(n):
        print("#",end = "")
    print()

#OR
#for i in range(n):
    #print("#" * n)
#Will do the same

