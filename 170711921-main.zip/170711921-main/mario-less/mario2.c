//Cs50 Week 1 Problem Set 1
//Promblem Set 1 improv1
//C Program to print a pattern of right aligned pyramid by prompting the user for the height of the same
//Reprompting the user with input validation using if conditionoal and do while loop

#include<cs50.h>
#include<stdio.h>

void space(int length);
void row(int l);

int main(void)
{
             int height=0;


             do               //A Loop is used to reprompt the user if the input is not within the expected range
            {
               height=get_int("Enter the height of the pyramid (within the range of 1 to 8 inclusive):");
               if (height <= 0 || height >8 )
                    printf("INVALID INPUT\n");      //Input Validation
            }
             while(height<=0 || height>8);

                for(int k=0;k<height;k++)
               {
                    space(k-1);
                     row(k+1);
               }

}

void space(int length)
{
    for(int i=7;i>length;i--)
    {
    printf(" ");
    }
}

void row(int l)
{
    for(int j=0;j<l;j++)
    {
        printf("#");
    }
    printf("\n");
}
