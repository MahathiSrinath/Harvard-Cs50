SELECT AVG(s.energy) from songs s
JOIN artists a on s.artist_id = a.id
WHERE a.name = 'Drake';
