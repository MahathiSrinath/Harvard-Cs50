//Cs50 Week2 Program1
//Exploring the utility of arrays
//scores improv program 3
#include<stdio.h>
#include<cs50.h>

int main(void)
{
    const int N=3;
    int scores[N];
     for(int i=0;i<N;i++)
     {
        scores[i]=get_int("Scores:\n");
     }

    printf("Average=%f\n",(scores[0]+scores[1]+scores[2])/(float)N);    //When one float number is used in the math, the result will be a float only
}
