//Cs50 Week2 Program2
//Exploring the utility of arrays
//hi improv program 3
#include<stdio.h>
#include<cs50.h>

int main(void)
{
    string words[2];    //An String is an array of characters
                        //Using an array to store strings kinda makes the array 2D
    words[0]="HI!";
    words[1]="BYE!";

    printf("%s\n%s\n",words[0],words[1]);
}
