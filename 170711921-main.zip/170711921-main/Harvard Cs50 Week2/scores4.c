//Cs50 Week2 Program1
//Exploring the utility of arrays
//scores improv program 4
#include<stdio.h>
#include<cs50.h>

const int N=3;
float average(int length,int array[]);

int main(void)
{
    int scores[N];
    for(int i=0;i<N;i++)        //Loop to prompt the user for input(scores)
    {
        scores[i]=get_int("Scores:\n");

    }
    printf("Average:%f\n",average(N,scores));
}

float average(int length,int array[])       //Function to itirate the adding up of the scores and to find the average
{
    int sum=0;
    for(int i=0;i<N;i++)
    {
        sum+=array[i];
    }
    return sum/(float)length;       //Function returns the average of the input scores
}
