//Cs50 Week2 Program1
//Exploring the utility of arrays
#include<stdio.h>

int main(void)
{
    int score1=72;
    int score2=73;
    int score3=33;

    printf("Average=%f\n",(score1+score2+score3)/3.0);    //When one float number is used in the math, the result will be a float only
}
