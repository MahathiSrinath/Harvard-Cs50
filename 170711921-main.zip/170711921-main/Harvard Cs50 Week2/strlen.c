//Cs50 Week2 Program3
//Functionality Implementation of the strlen function

#include<stdio.h>
#include<cs50.h>

int main(void)
{
    string name=get_string("Enter your name:");

    int counter=0;
    while(name[counter]!='\0')
    {
        counter++;
    }
    printf("Length of the string is:%i\n",counter);
}
