//Cs50 Week2 Program4
//Functionality Implementation of the %s in printf function
//string improv program 1

#include<stdio.h>
#include<cs50.h>
#include<string.h>

int main(void)
{
    string str=get_string("Input:  ");
    printf("Output: ");

    for(int i=0,length=strlen(str);i<length;i++)      //Prints word character by character
    {
        printf("%c",str[i]);
    }
    printf("\n");
}
