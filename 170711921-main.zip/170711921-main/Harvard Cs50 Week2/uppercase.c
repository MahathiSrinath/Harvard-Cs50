//Cs50 Week2 Program5
//Functionality Implementation of toupper function in the ctype library

#include<stdio.h>
#include<cs50.h>
#include<string.h>

int main(void)
{
    string str=get_string("Input:  ");
    printf("Output: ");

    for(int i=0,length=strlen(str);i<length;i++)      //Prints word character by character
    {
        if(str[i]>='a' && str[i]<='z')  //If lowercase
        {
             printf("%c",str[i]-32);    //A Pattern according to ASCII chart that the difference between lowercase and uppercase is 32
        }
        else
        {
            printf("%c",str[i]);
        }

    }
    printf("\n");
}
