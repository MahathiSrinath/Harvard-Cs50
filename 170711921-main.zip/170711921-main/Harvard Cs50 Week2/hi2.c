//Cs50 Week2 Program2
//Exploring the utility of arrays
//hi improv program 2
#include<stdio.h>
#include<cs50.h>

int main(void)
{
    string s="HI!";
    string t="BYE!";

    printf("%s\n%s\n",s,t);
}
