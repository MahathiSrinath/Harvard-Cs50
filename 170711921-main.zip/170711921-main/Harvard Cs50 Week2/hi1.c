//Cs50 Week2 Program2
//Exploring the utility of arrays
//hi improv program 1
#include<stdio.h>
#include<cs50.h>

int main(void)
{
    string s="HI!";

    printf("%c%c%c\n",s[0],s[1],s[2]);  //A String is just an array of characters where s is one single variable containing the value HI!
}
