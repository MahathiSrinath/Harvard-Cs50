//Cs50 Week2 Program1
//Exploring the utility of arrays
//scores improv program 2
#include<stdio.h>
#include<cs50.h>

int main(void)
{
    int scores[3];
     for(int i=0;i<3;i++)
     {
        scores[i]=get_int("Scores:\n");
     }

    printf("Average=%f\n",(scores[0]+scores[1]+scores[2])/3.0);    //When one float number is used in the math, the result will be a float only
}
