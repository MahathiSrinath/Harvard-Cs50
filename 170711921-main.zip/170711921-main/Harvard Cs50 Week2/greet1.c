//Cs50 Week2 Program6
//Exploring the command line arguements
#include<stdio.h>
#include<cs50.h>
#include<string.h>

int main(int argc,string argv[])
{
   for(int i=0;i<argc;i++)
   {
    printf("%s\n",argv[i]);
   }
}
