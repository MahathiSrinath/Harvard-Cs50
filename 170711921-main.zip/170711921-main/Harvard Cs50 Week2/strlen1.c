//Cs50 Week2 Program3
//Functionality Implementation of the strlen function
//strlen improv program 1

#include<stdio.h>
#include<cs50.h>

int length(string name);

int main(void)
{
    string name=get_string("Enter your name:");
     printf("The Length of the name is:%i\n",length(name));
}

int length(string name)
{
    int counter=0;
    while(name[counter]!='\0')
    {
        counter++;
    }
    return counter;
}
