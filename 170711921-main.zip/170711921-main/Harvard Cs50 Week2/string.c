//Cs50 Week2 Program4
//Functionality Implementation of the %s in printf function

#include<stdio.h>
#include<cs50.h>
#include<string.h>

int main(void)
{
    string str=get_string("Input:  ");
    printf("Output: ");

    for(int i=0;i<strlen(str);i++)      //Prints word character by character
    //But design wise,code is bad because length of the string is being checked again and again even though it doesnt change
    //strlen function is being called multiple tiimes unecessarily
    {
        printf("%c",str[i]);
    }
    printf("\n");
}
