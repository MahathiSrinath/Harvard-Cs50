//Cs50 Week 2 Problem Set 1
//C Program to implement a scrabble game in an array
#include<stdio.h>
#include<cs50.h>
#include<ctype.h>
#include<string.h>

int points[]={1,3,3,2,1,4,2,4,1,8,5,1,3,1,1,3,10,1,1,1,1,4,4,8,4,10};
int compute(string word);

int main(void)
{
    printf("Let's Play SCRABBLE!\n");

    string word1=get_string("Player1: \n");
    string word2=get_string("Player2: \n");

    int score1=compute(word1);
    int score2=compute(word2);

    {
        if(score1 > score2)
        {
            printf("Player 1 wins!\n");
        }
        else if(score1 == score2)
        {
            printf("Tie!\n");
        }
        else
        {
            printf("Player 2 wins!\n");
        }
    }

}

int compute(string word)
{
    int score=0;

    for(int i=0,length=strlen(word);i<length;i++)
    {
        if(isupper(word[i]))
        {
            score=score+points[word[i]-65];

        }
        else if(islower(word[i]))
        {
            score=score+points[word[i]-97];
        }
    }

    return score;
}
