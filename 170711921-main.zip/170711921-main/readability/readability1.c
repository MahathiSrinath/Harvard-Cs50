//Cs50 Week 2 Problem Set 2
//C Program to guess the standard of the input text
#include<stdio.h>
#include<cs50.h>
#include<ctype.h>
#include<string.h>
#include<math.h>

int main(void)
{
    string text=get_string("Text: ");
    int letters=0,words=1,sentences=0;  //words=spaces+1

    for(int i=0,length=strlen(text);i<length;i++)
        {
            if(isalpha(text[i]))  //Check whether char is an alphabet with reference to ASCII chart
            {
                letters++;
            }
            else if(text[i]==' ')
            {
                words++;
            }
            else if(text[i]=='.' || text[i]=='?' || text[i]=='!' )
            {
                sentences++;
            }
        }

        //Coleman-Liau index

        float L= (float)letters/words*100;
        float S= (float)sentences/words*100;
        int index = round(0.0588 * L - 0.296 * S - 15.8);

        if(index<1)
        {
            printf("Before Grade 1\n");
        }
        else if(index>16)
        {
            printf("Grade 16+\n");
        }
        else
        {
            printf("Grade %d\n",index);
        }
}
