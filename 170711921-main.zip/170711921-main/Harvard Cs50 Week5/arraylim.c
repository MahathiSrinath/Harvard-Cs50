//CS50 Week5 Program1
//Exploring limitation of an array, Intro to Linked List
#include<stdio.h>

int main(void)
{
    int list[3];
    list[0] = 1;
    list[1] = 2;
    list[2] = 3;

    for(int i = 0; i < 3; i++)
    {
        printf("%d\n",list[i]);
    }
}
