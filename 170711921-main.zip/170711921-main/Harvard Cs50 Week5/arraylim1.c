//CS50 Week5 Program1
//Exploring limitation of an array, Intro to Linked List
//arraylim improv program1
#include<stdio.h>
#include<stdlib.h>

int main(void)
{
    int *list = malloc(3* sizeof(int));
    if (list == NULL)
    {
        return 1;
    }
    list[0] = 1;
    list[1] = 2;
    list[2] = 3;

    int *temp = malloc(4 * sizeof(int));
     if (list == NULL)
    {
        free(list); //Preventing memory leak
        return 1;
    }

    for(int i = 0; i < 3; i++)
    {
        temp[i] = list[i];
    }   temp[3] = 4;

    free(list);
    list = temp;    //Same values are assigned to list as temp
                //Because both are pointers pointing to the same addy

    for(int i = 0; i < 4; i++)
    {
        printf("%d\n",list[i]);
    }
}
