//CS50 Week1 Program9
//blocks improv Program2
#include<stdio.h>
#include<cs50.h>

int j=3;
int i=3;
int main(void)
{

    while (j>0)
        {

        while(i>0)
            {
            printf("#");
            i--;
            }
        printf("\n");
        j--;
        }

}
