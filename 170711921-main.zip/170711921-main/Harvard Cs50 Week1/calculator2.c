//CS50 Week1 Program7
//calculator improv Program2
//Program using idea of data abstraction
#include<stdio.h>
#include<cs50.h>

int add(int a,int b);
int main(void)
{
    int x=get_int("x:");
    int y=get_int("y:");

    printf("%i\n",add(x,y));  //Using the mathematical concept of function composition
}

int add(int a,int b)
{
    return a+b;
}
