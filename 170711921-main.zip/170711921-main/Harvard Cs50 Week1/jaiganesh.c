// (My First Code)
//CS50 Week1 Program1
//Jai Guru-Ganapathy-Devi
#include <stdio.h>
int main(void)
{
    printf("Jai Guru-Ganapathy-Devi\n");
}
