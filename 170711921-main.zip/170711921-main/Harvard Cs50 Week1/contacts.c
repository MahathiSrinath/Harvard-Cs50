//CS50 Section Week1
//Program1
#include<cs50.h>
#include<stdio.h>

int main(void)
{
    int i=0;
    while(i>=0)
    {
        string name=get_string("Enter the name: ");
        int age=get_int("Enter the age: ");
        string number=get_string("Enter the phone number: ");
        printf("Name=%s\nAge=%i\nPhone Number=%s\n",name,age,number);
        i++;
    }
}
