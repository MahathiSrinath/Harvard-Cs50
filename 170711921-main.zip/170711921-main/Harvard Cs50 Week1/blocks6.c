//CS50 Week1 Program9
//blocks improv Program6
#include<stdio.h>
#include<cs50.h>

int main(void)
{
    int n;
    do
    {
        int n=get_int("Size:");
    }
    while(n>=1)

    for (int i=0;i<n;i++)
    {
        for (int j=0;j<n;j++)
       {
         printf("#");
       }

        printf("\n");
    }

}
