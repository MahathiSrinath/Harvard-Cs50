//CS50 Week1 Program6
//Creating a function
//bow improv program1
#include<stdio.h>

void bow(void);

int main(void)
{
    for(int i=3;i>0;i--)
    bow();
}

void bow(void)        //Defining the function bow()
{
    printf("BOW!\n");
}
