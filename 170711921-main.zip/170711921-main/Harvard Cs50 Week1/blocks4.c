//CS50 Week1 Program9
//blocks improv Program4
#include<stdio.h>
#include<cs50.h>

int main(void)
{
    for (int i=0;i<3;i++)
    {
        for (int j=0;j<3;j++)
       {
         printf("#");
       }

        printf("\n");
    }

}

