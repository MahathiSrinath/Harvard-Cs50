//CS50 Week1 Program8
#include<stdio.h>

int main(void)
{
    printf("???");
    printf("\n");
}
