//CS50 Week1 Program6
//Creating your own function
#include<stdio.h>

void bow(void)        //Defining the function bow()
{
    printf("BOW!\n");
}

int main(void)
{
    for(int i=3;i>0;i--)
    bow();
}
