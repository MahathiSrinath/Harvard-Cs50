//CS50 Week1 Program3
//Comparision of Numbers using Conditionals
//compare improv prog1
#include<stdio.h>
#include<cs50.h>

int main(void)
{
    int x= get_int("Enter x value\n");
    int y=get_int("Enter y value\n");

    if(x<y)
     {
        printf("x is less than y\n");
     }

    else if(x>y)
    {
        printf("x is greater than y\n");
    }

    else
    {
    printf("x is equal to y\n");
    }

}
