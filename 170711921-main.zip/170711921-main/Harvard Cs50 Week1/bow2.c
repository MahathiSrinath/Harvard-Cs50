//CS50 Week1 Program6
//bow improv program2
#include<stdio.h>

void bow(int n);

int main(void)
{
   bow(3);
}

void bow(int n)             //bow() Implementation Details
{
    for(int i=0;i<n;i++)
    printf("BOW!\n");
}
