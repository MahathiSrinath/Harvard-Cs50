//CS50 Week1 Program 5
//Decrement Operator
#include<stdio.h>

int main(void)
{
    int i=3;
    while(i>0)
    {
        printf("Order\n");
        i=i-1;              /* i-=1 OR i-- can also be used */
    }
}
