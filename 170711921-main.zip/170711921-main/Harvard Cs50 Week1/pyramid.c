//CS50 Section Week1
//Program2
#include<cs50.h>
#include<stdio.h>


void row(int l);
int main(void)
{
    int h=get_int("Enter the height of the pyramid: ");
    for(int i=1;i<=h;i++)
    {
      row(i);   //row(i+1) can also be used when i=0 just because we want to print one more hash than what is already there in the previous row
    }

}

void row(int l)
{
    for(int i=0;i<l;i++)
    {
        printf("#");
    }
       printf("\n");
}
