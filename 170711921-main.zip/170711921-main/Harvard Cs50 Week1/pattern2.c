//CS50 Week1 Program8
//mario improv Program2
#include<stdio.h>
#include<cs50.h>

int main(void)
{
  for(int i=0;i<3;i++)
  {
    printf("?");
  }
  printf("\n");
}
