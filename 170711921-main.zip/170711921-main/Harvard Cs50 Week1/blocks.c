//CS50 Week1 Program9
#include<stdio.h>

int main(void)
{
    printf("###\n");
    printf("###\n");
    printf("###\n");
}
