//CS50 Week1 Program 5
//Increment Operator
#include<stdio.h>

int main(void)
{
    int i=1;
    while(i<=3)
    {
        printf("Order\n");
        i=i+1;              /* i+=1 OR i++ can also be used */
    }
}
