//CS50 Week1 Program9
//blocks improv Program1
#include<stdio.h>
#include<cs50.h>

int main(void)
{
     int j=3;
    while (j>0)
        {
        int i=3;
        while(i>0)
            {
            printf("#");
            i--;
            }
        printf("\n");
        j--;
        }

}
