//Program to calculate simple interest
#include<stdio.h>

int main(void)
{
    int principal,time_period_in_years,rate_of_interest,simple_interest;

    printf("Enter the Principal amount:\n");
    scanf("%d",&principal);
    printf("Enter the Time Period:\n");
    scanf("%d",&time_period_in_years);
    printf("Enter the rate of interest:\n");
    scanf("%d",&rate_of_interest);
    simple_interest=(principal*time_period_in_years*rate_of_interest)/100;
    printf("Simple Interest:%d\n",simple_interest);


}
