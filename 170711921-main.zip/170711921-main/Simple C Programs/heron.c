//Program to calculate the area of a triangle using heron's formula
#include<stdio.h>
#include<math.h>

int main(void)
{
    int semi_perimeter,side_a,side_b,side_c;
    double area;
    printf("Enter the length of the sides of the triangle a,b and c respectively:\n");
    scanf("%d\n%d\n%d",&side_a,&side_b,&side_c);
    semi_perimeter=(side_a+side_b+side_c)/2;
    area=sqrt((semi_perimeter)*(semi_perimeter-side_a)*(semi_perimeter-side_b)*(semi_perimeter-side_c));
    printf("The Area of the given triangle is:%lf meter sq.\n",area);
}
