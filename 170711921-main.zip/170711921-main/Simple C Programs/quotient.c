// Program to obtain quotient on dividing two numbers
#include<stdio.h>

int main(void)
{
    int num=0,denom=0;
    float quo;
     printf("Enter the value of numerator:");
    scanf("%d",&num);
    printf("Enter the value of denominator:");
    scanf("%d",&denom);


    if(denom!=0)
    {
        quo=((float)num/denom);                //Truncation
        printf("Quotient=%f\n",quo);
    }

    else
    {
        printf("Quotient=Not defined\n");

    }
}
