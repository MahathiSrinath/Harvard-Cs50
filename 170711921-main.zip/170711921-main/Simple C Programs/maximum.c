//Program to obtain the maximum of two numbers
#include<stdio.h>

int main(void)
{
    int num1,num2;
    printf("Enter the value of number1:");
    scanf("%d",&num1);
    printf("Enter the value of number2:");
    scanf("%d",&num2);

    if(num1>num2)
    {
        printf("Maximum number=%d\n",num1);
    }

    else
    {
        printf("Maximum number=%d\n",num2);
    }
}
