//CHESS BOARD
#include<stdio.h>

int main(void)
{
    
}
