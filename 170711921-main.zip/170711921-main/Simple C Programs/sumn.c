//Program to calculate the sum of first n natural numbers
#include<stdio.h>

int main(void)
{
    int n,sum;
    printf("How many numbers sum do you want?\n");
    scanf("%d",&n);
    sum=((n*(n+1))/2);
    printf("Sum of first %d natural numbers is:%d\n",n,sum);

}
