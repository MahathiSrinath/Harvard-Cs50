//This Program gives ASCII Values
//Code written by me
#include <stdio.h>
#include<cs50.h>
int main(void)
{
    int n=1;

    n=get_char("Enter a char: ");
    printf("Ascii value of character:%i\n",n);

}
