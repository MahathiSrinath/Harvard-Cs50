//Program to add the elements of the array
#include<stdio.h>

int main(void)
{
    int arr[],sum;
    printf("Enter the elements of the array\n");
    scanf("%d",&arr[]);
    printf("The Array elements are:%d\n",arr[]);

    sum+=arr[];
    printf("The Sum of the array elements are:%d\n",sum);

}
