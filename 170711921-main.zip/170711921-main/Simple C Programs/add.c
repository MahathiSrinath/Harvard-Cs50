//Program to add two numbers
#include<stdio.h>

int main(void)
{
    int num1=0;
    int num2=0;
    int sum;

    printf("Enter the value of number1:");
    scanf("%d",&num1);
    printf("Enter the value of number2:");
    scanf("%d",&num2);
    sum=num1+num2;
    printf("Sum=%d\n",sum);
}
