#Cs50 Week 6 Problem Set 2
#Python Program to print a pattern of right aligned pyramid by prompting the user for the height of the same
from cs50 import get_int

while True:
    height = get_int("Enter the height of the pyramid: ")
    if(height > 0 and height < 9):
        break

for level in range(height):
    print(" " * (height-level-1), end ="")
    print("#" * (level+1))

