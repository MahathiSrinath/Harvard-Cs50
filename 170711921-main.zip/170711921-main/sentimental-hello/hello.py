#Cs50 Week 6 Problem Set 1
#Python Program to prompt the user for their name and greet 
answer = input("What is your name? ")
print(f"Hello, {answer}")
