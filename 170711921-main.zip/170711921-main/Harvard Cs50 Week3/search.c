//Cs50 Week3 Program1
//Implementation of searching algorithms in arrays
#include<stdio.h>
#include<cs50.h>

int main(void)
{
    int numbers[]={5,10,15,20,25,50,100};
    int size=sizeof(numbers);
    int num=get_int("Enter the number to search: ");

    for(int i=0;i<size;i++)
    {
        if(numbers[i]==num)
        {
            printf("Found!\n");
            return 0;
        }

    }

    printf("Not Found!\n");
}
