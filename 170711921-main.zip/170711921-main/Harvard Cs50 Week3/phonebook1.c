//Cs50 Week3 Program3
//Implementation of searching algorithms in a structure
//phonebook improv program 1
#include<stdio.h>
#include<cs50.h>
#include<string.h>

typedef struct person
{
    string names;
    string numbers;
}people[];

int main(void)
{
    //person people[3];

    people[0].names = "minz";
    people[0].numbers = "+91-111";


    people[1].names = "mahathi";
    people[1].numbers = "+91-333";


    people[2].names = "mahima";
    people[2].numbers = "+91-1111";


    string name=get_string("Enter the name to search: ");

    for(int i=0;i<3;i++)
    {
        if(strcmp(people[i].names,name)==0)    //ASCII-betically congruent
        {
            printf("Found!\n");
            printf("Contact Number:%s\n",people[i].numbers);
            return 0;
        }

    }

    printf("Not Found!\n");
    return 1;

}
