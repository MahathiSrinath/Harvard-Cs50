//Cs50 Week3 Program3
//Implementation of searching algorithms in array of characters(strings)
#include<stdio.h>
#include<cs50.h>
#include<string.h>

int main(void)
{
    string names[]={"minz","mahathi","mahima"};
    string number[]={"+91-111","+91-333","+91-1111"};
    string name=get_string("Enter the name to search: ");

    for(int i=0;i<3;i++)
    {
        if(strcmp(names[i],name)==0)    //ASCII-betically congruent
        {
            printf("Found!\n");
            printf("Contact Number:%s\n",number[i]);
            return 0;
        }

    }

    printf("Not Found!\n");
    return 1;
}
