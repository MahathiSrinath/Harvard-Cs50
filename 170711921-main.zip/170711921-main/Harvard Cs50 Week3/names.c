//Cs50 Week3 Program2
//Implementation of searching algorithms in array of characters(strings)
#include<stdio.h>
#include<cs50.h>
#include<string.h>

int main(void)
{
    string names[]={"minz","mahathi","meenakshi","mahima","mekhala","mahalakshmi"};
    string name=get_string("Enter the name to search: ");

    for(int i=0;i<7;i++)
    {
        if(strcmp(names[i],name)==0)    //ASCII-betically congruent
        {
            printf("Found!\n");
            return 0;
        }

    }

    printf("Not Found!\n");
    return 1;
}
