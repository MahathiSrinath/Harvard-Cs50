//CS50 Week4 Program1
//Understanding number representation in computers
#include<stdio.h>

int main(void)
{
    int num = 11;
    printf("The Hexadecimal representation of %d is %X\n",num,num);
}
