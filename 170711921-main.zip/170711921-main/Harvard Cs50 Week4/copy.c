//Cs50 Week4 Program11
//File Operations
#include<stdio.h>
#include<stdint.h>

typedef uint8_t BYTE;

int main(int argc,char *argv[])
{
    FILE *source = fopen(argv[1],"rb");
    FILE *destination = fopen(argv[2],"wb");

    BYTE b;

    while(fread(&b,sizeof(b),1,source) != 0)
    {
        fwrite(&b,sizeof(b),1,destination);
    }

    fclose(destination);
    fclose(source);
}
