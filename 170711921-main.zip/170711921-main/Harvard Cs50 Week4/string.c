//CS50 Week4 Program3
//Understanding string as pointer underneath the hood
#include<stdio.h>
#include<cs50.h>

int main(void)
{
    string s = "HI!";
    printf("Address of H is:%p\n",s);  //String by default points to the first char
    printf("Check:%p\n",&s[0]);    //Conforming the concept by actually checking the addy of H
    printf("Address of I is:%p\n",&s[1]);   //Check for
    printf("Address of ! is:%p\n",&s[2]);      // contigious
    printf("Address of null char is: %p\n",&s[3]);  // memory locations
}
