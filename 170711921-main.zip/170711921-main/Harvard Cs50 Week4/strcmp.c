// Cs50 Week4 Program4
//Exploring the working of string(which is basically a pointer to the first element) in memory
#include<stdio.h>
#include<cs50.h>
#include<string.h>

int main(void)
{
    printf("Comparision of numbers using equality operator\n");
    int num1 = get_int("num1 : ");
    int num2 = get_int("num2 : ");


    if(num1 == num2)
    {
        printf("Same\n");
    }
    else
    printf("Different\n");

    printf("Comparision of strings using equality operator\n");
    string string1 = get_string("string1 : ");
    string string2 = get_string("string2 : ");


    if(string1 == string2)
    {
        printf("Same\n");
    }
    else
    printf("Different\n");

    printf("string1 points to : %p\n",string1);
    printf("string2 points to : %p\n",string2);

    printf("Comparision of strings using strcmp()\n");
    string str1 = get_string("str1 : ");
    string str2 = get_string("str2 : ");


    if(strcmp(str2,str1)==0)
    {
        printf("Same\n");
    }
    else
    printf("Different\n");


    /*Takeaway: strcmp compares a string char by char and not by addresses
                unlike equality operator(==) compares a string*/

}
