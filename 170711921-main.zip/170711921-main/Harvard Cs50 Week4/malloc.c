// Cs50 Week4 Program7
//Exploring the utility of malloc()
#include<stdio.h>
#include<cs50.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>

int main(void)
{   //Value of a number can be assigned to another variable
    //Any operation done on num2 does not affect num1
    printf("\nNumbers\n");
    int num1 = get_int("Input: ");
    int num2 = num1;
    num2++;
    printf("num1: %d\n",num1);
    printf("Incremented num1: %d\n",num2);

    //But the same does not hold good for strings
    //The Assignment operator assigns the value of s to t which is the addy to the first variable
    //Which implies both s and t point to the same address. Hence any changes in t reflects in s
    printf("\nStrings\n");
    string string1 = get_string("Input: ");
    string assigned_string1 = string1;

    if(strlen(assigned_string1)>0)     //Checking for segmentation fault
    {
        assigned_string1[0] = toupper(assigned_string1[0]);
    }

    printf("String: %s\n",string1);
    printf("Assigned String: %s\n",assigned_string1);

    //We can overcome this drawback by using the malloc()
    //It assigns a seperate specified chunck of memory(A Duplicate of the datatype)
    //As a duplicate has a seperate addy, any changes made in it does not affect the original data
    printf("\nMalloc function's Magic\n");
    string string2 = get_string("Input: ");
    string dup_string2 = malloc(sizeof(string2));

    //Duplicating Values of string
    /*Implementation Details of strcpy
    for(int i = 0,length = strlen(string2); i<= length;i++)
    {
        dup_string2[i]=string2[i];
    }*/

    strcpy(dup_string2,string2);

    if(strlen(dup_string2)>0)     //Checking for segmentation fault
    {
        dup_string2[0] = toupper(dup_string2[0]);
    }

    printf("String: %s\n",string2);
    printf("Duplicate String: %s\n",dup_string2);

    free(dup_string2);  //Releasing allocated memory to prevent memory leak

}
