//Cs50 Week4 Program9
//Understanding Pass by value/copy and Pass by reference
#include<stdio.h>

void pass_by_value(int x, int y);
void pass_by_reference(int *x, int *y);

int main(void)
{
    int a = 5,b =10;
    printf("Before Swapping\n");
    printf("a=%d\nb=%d\n",a,b);
    pass_by_value(a,b);
    printf("Pass By Value/Copy\n");
    printf("a=%d\nb=%d\n",a,b);
    pass_by_reference(&a,&b);
    printf("Pass By Reference\n");
    printf("a=%d\nb=%d\n",a,b);

}

void pass_by_value(int x, int y)
{
    int temp;
    temp = x;
    x = y;
    y = temp;
}

void pass_by_reference(int *x, int *y)
{
    int temp;
    temp = *x;
    *x = *y;
    *y = temp;
}
