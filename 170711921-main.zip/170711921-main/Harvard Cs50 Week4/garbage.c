// Cs50 Week4 Program5
//Garbage Values
#include<stdio.h>

int main()
{
    int scores[1024];
    for(int i=0 ; i < 1024 ; i++)
    {
        printf("%d\n",scores[i]);
    }
}
