//Cs50 Week4 Program6
//Exploring the consequeces of dereferencing unallocated memory
#include<stdio.h>
#include<stdlib.h>
#include<cs50.h>

int main(void)
{
    int *x,*y;
    x = malloc(sizeof(int));  //Allocating pointee
    *x = 42;    //dereferencing
    /* *y = 13; //commenting out the code because it is a bad idea to dereference unallocated memory*/
    y = x;  //allots same size as x
    *y = 13;    //points to the same location as x

    printf("x=y=%d\n",*x);

}
