//Cs50 Week4 Program8
//Implementing the get functions using scanf()
#include<stdio.h>

int main(void)
{
    int n;
    printf("Enter the Number: ");
    scanf("%d",&n);
    printf("Number:%d\n",n);

    char *s;    //String can also be treated as an array of chars to prevent segmentation fault to an extent
    printf("Enter the String: ");
    scanf("%s",s);  //String itself is the addy of its first variable
    printf("String:%s\n",s);
}

//Takeaway : The scanf() prevents overflow
//However if string entered is greater than size of array segmnetation fault occurs
//Hence get functions keeps allocating memory as and when user inputs
