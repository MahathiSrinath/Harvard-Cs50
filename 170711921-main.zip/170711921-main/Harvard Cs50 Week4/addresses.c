//CS50 Week4 Program2
//Understanding POINTERS
#include<stdio.h>

int main(void)
{
    int n = 50;
    int *p = &n;    //pointer declaration
    printf("%p\n",p);
     printf("%i\n",*p); //pointer dereferencing
}
