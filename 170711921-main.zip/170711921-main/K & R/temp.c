//Conversion of Fahrenhiet to Celsius from a range of 0 to 300 with every +20 raise in temperature
#include<stdio.h>

int main(void)
{
    int fahr,cel,upper,lower,step;
    lower=0;     //code works perfectly well even without lower but,fahr has to be initialized to 0.
    upper=300;
    step=20;    //step is an unnecessary variable.Instead fahr can be incremented by 20 at the end of excecution of while loop.
    fahr=lower;

    while(fahr<=upper)
    {
        cel=5*(fahr-32)/9;
        printf("%d\t%d\n",fahr,cel);
        fahr=fahr+step;
    }
}
