//Program to count the number of characters,lines and words in a given input
#include<stdio.h>
#include<cs50.h>
#define IN 1
#define OUT 0

int main(void)
{
    int c,nc,nl,nw,state;
    c=0;nc=0;nl=0;nw=0;state=OUT;

       while((c=getchar())!=EOF)
      {
         {
            ++nc;
         }

         if(c=='\n')
         {
            ++nl;
         }

         if(c==' '||c=='\n'||c=='\t'||c=='\0')
         {
            state=OUT;
         }
         else if(c==OUT)
         {
            state=IN;
            ++nw;
         }

         if(nc>0)
         {
            ++nl;
            ++nw;
         }

      }

      printf("Char count:%d\nLine count:%d\nWord count:%d\n",nc,nl,nw);

}

