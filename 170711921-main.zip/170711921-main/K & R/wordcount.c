//Program to count the number of words in a given input
#include<stdio.h>
#include<cs50.h>
#define OUT 0 //outside word or white space
#define IN 1 //inside word

int main()
{
    int c=0,nw=0;
    int state=OUT;


       while((c=getchar())!=EOF)
      {

         if(c==' '||c=='\n'||c=='\t')
         state=OUT;


         else if(c==OUT)
         {
            state=IN;
          nw++;
         }

    }
      printf("Word count:%d\n",nw);

}
     printf("Word Count=%d\n",nw);
}
