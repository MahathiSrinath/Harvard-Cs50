//Program to count the number of characters in a given input
#include <stdio.h>
#include<cs50.h>
#include<string.h>

int main()
{
 int nc=0;

     while (getchar() != EOF)
     {
      ++nc;
     }

     printf("Charcount:%d\n",nc);
}











