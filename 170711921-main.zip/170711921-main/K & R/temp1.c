//Fahrenhiet to Celsius Temperature Conversion
//Improv Program1

#include<stdio.h>
#include<cs50.h>

int main(void)
{
    int fah,cel;

    fah=get_int("enter the temprature in fahrenhiet:\n");

    cel=5*(fah-32)/9;
    printf("temperature in celsius is:%i\n",cel);

}
