//Program to count the number of lines in the given input
#include <stdio.h>
#include<cs50.h>

int main()
{

int c=0;
int nl=0;
            while ((c = getchar())!= EOF)
           {
               if (c == '\n')
               nl++;
           }

           printf("Line count=%d\n", nl);

}
