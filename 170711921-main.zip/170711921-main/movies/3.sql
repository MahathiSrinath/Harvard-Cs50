SELECT title from movies
WHERE year >= 2018
ORDER BY title ASC;
