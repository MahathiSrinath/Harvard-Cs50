SELECT title from movies
WHERE year = 2008;
