SELECT title,year from movies
WHERE title LIKE 'Harry Potter%'
ORDER BY year ASC;
