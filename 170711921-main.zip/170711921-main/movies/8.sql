SELECT p.name from people p
JOIN stars s on p.id = s.person_id
JOIN movies m on s.movie_id = m.id
WHERE m.title = 'Toy Story';
