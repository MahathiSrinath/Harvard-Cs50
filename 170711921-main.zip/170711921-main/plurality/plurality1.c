//Cs50 Week 3 Problem Set 2
//Virtual Elections in the terminal
//plurality improve program 1
#include<stdio.h>
#include<cs50.h>
#include<string.h>
#include<ctype.h>

int main(int argc,char * argv[])
{

    int candidate1=0,candidate2=0,candidate3=0;

     if (argc != 4)
     {
        printf("Usage: ./plurality candidates\n");
        return 1;
     }
            for (int i = 1; i < argc; i++)
        {
            for (int j = 0; j < strlen(argv[i]); j++)
            {
                if (!isalpha(argv[i][j]))
                {
                    printf("Candidate names must only contain letters!\n");
                    return 1;
                }
            }
        }



    char votes[3][50];
        for(int k=0;k<3;k++)
        {
            printf("Vote: ");
            scanf("%49s",votes[k]);     // Limiting input to 50 letters to avoid buffer overflow
            if(!strcmp(votes[k],argv[k+1]))
            {
                printf("Invalid Input!\n");
            }


        }

        for (int l = 0; l < 3; l++)
        {
            if (strcmp(votes[l], argv[1]) == 0)
            {
                candidate1++;
            }
            else if (strcmp(votes[l], argv[2]) == 0)
            {
                candidate2++;
            }
            else if (strcmp(votes[l], argv[3]) == 0)
            {
                candidate3++;
            }
        }

        if(candidate1>candidate2 && candidate1>candidate3)
        {
            printf("%s\n",argv[1]);
        }

         else if(candidate2>candidate3 && candidate2>candidate1)
        {
            printf("%s\n",argv[2]);
        }

         else if(candidate3>candidate1 && candidate3>candidate2)
        {
            printf("%s\n",argv[3]);
        }

        return 0;
}
