//Cs50 Week 1 Problem Set 1
//C Program to calculate the number of coins to make up for change owed

#include<stdio.h>
#include<cs50.h>

int main(void)
{
     int cents,coins=0,quater=25,dime=10,nickel=5,penny=1;


        do
        {
          cents=get_int("Enter the Change Owed: ");
        }while(cents<0);


          while(cents>=quater)
         {
            cents-=quater;
            coins++;
         }

          while(cents>=dime)
         {
            cents-=dime;
            coins++;
         }

          while(cents>=nickel)
         {
            cents-=nickel;
            coins++;
         }

          while(cents>=penny)
         {
            cents-=penny;
            coins++;
         }

    printf("%d\n",coins);
}
