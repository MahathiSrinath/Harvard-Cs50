//Cs50 Week 1 Problem Set 1
//C Program to print a pattern of mirror pyramid by prompting the user for the height of the same

#include<cs50.h>
#include<stdio.h>

void space1(int length);
void right(int l);
void left(int l);
void space2(void);

int main(void)

{
            int height=0;
            do            //A Loop is used to reprompt the user if the input is not within the expected range
            {
               height=get_int("Enter the height of the pyramid(within the range of 1 to 8 inclusive):");
            }
             while(height<=0 || height>8);

                for(int k=0;k<height;k++)
               {
                    space1(k-1);
                     right(k+1);
                     space2();
                     left(k+1);
               }

}

void space1(int length)
{
    for(int i=7;i>length;i--)
    {
    printf(" ");
    }
}

void right(int l)
{
    for(int j=0;j<l;j++)
    {
        printf("#");
    }
}

void left(int l)
{
    for(int i=0;i<l;i++)
    {
        printf("#");
    }
       printf("\n");
}

void space2(void)
{
    printf("  ");
}
